# Edit Inline


I have built this little edit in place profile widget, except it's not working. If I don't deliver it to the client within 4 hours, millions of pounds will be wasted and I will end up living in a forest, eating pine cones. Please can you save me?

I should be able to click the edit link and edit the firstName field, but for some reason it's not saving!

P.S. I suspect a scope issue.
