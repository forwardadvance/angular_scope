# Profile form broken. Extreme danger.

Help! Dinosaurs are attacking the city and eating everyone alive. 

Fortunately, as we all know, dinosaurs are afraid of Kryptonite. Our scientists have built a little form which we can use to allocate Kryptonite to all the citizens, but it's not working. Please can you help us fix it before it's too late?

Thanks!

P.S. We also suspect a scope issue.
